import java.util.ArrayList;
public class TEAlgo 
{
    public static void m() 
    {
    	int fg_size = 2;
    	flgrp_class[] f1 = new flgrp_class[fg_size];
    	ArrayList<Double> f_share_l = new ArrayList<Double>();
    	int size_mat = 37;
    	GraphMap graph = new GraphMap();
    	graph.twowayvertex("1", "21", "5", "1");
    	graph.twowayvertex("2", "21", "5", "1");
    	graph.twowayvertex("3", "21", "5", "1");
    	graph.twowayvertex("4", "21", "5", "1");
    	graph.twowayvertex("5", "22", "5", "1");
    	graph.twowayvertex("6", "22", "5", "1");
    	graph.twowayvertex("7", "22", "5", "1");
    	graph.twowayvertex("8", "22", "5", "1");
    	graph.twowayvertex("9", "23", "5", "1");
    	graph.twowayvertex("10", "23", "5", "1");
    	graph.twowayvertex("11", "23", "5", "1");
    	graph.twowayvertex("12", "23", "5", "1");
    	graph.twowayvertex("13", "24", "5", "1");
    	graph.twowayvertex("14", "24", "5", "1");
    	graph.twowayvertex("15", "24", "5", "1");
    	graph.twowayvertex("16", "24", "5", "1");
    	graph.twowayvertex("17", "25", "5", "1");
    	graph.twowayvertex("18", "25", "5", "1");
    	graph.twowayvertex("19", "25", "5", "1");
    	graph.twowayvertex("20", "25", "5", "1");
    	graph.twowayvertex("1", "5", "5", "1");
    	graph.twowayvertex("2", "9", "5", "1");
    	graph.twowayvertex("3", "13", "5", "1");
    	graph.twowayvertex("4", "17", "5", "1");
    	graph.twowayvertex("6", "10", "5", "1");
    	graph.twowayvertex("7", "14", "5", "1");
    	graph.twowayvertex("8", "18", "5", "1");
    	graph.twowayvertex("11", "15", "5", "1");
    	graph.twowayvertex("12", "19", "5", "1");
    	graph.twowayvertex("16", "20", "5", "1");
		
		double[][] cap_matr = new double[size_mat][size_mat];
		cap_matr = graph.capacity_matrix();
		
		System.out.println("beginning value of initial matrix - ");
		
		for(int i = 1; i<size_mat; i++)
		{
			for(int j = 1; j<size_mat; j++)
			{
				System.out.print("\t"+cap_matr[i][j]);
			}
			System.out.println();
		}
		
		for (int i = 0; i< fg_size; i++)
		{
			f1[i] = new flgrp_class(graph);	
		}

		double f_share = 0.001;
		double y0,y1;
		double y2,y3;
		boolean contn = true;
		
		while(contn)
		{
			
			if(f1[0].srttunnellist_size() == 0)
			{
				f1[0].valid = 0;
			}
			
			if(f1[1].srttunnellist_size() == 0)
			{
				f1[1].valid = 0;
			}
			
			y0 = f1[0].limit_getter(0, f_share) - f1[0].d1; //f_satisfied
			y0 = Math.round(y0 * 100);
			y0 = y0/100;
			y1 = f1[1].limit_getter(1, f_share) - f1[1].d1;
			y1 = Math.round(y1 * 100);
			y1 = y1/100;

			
			//--------------------------------------------------------------

			while(f1[0].srttunnellist_size()>0 && f1[0].func_bot_nec(cap_matr)== 0 && f1[0].valid == 1)
			{
					f1[0].tunnel_list.remove(0);
					if(f1[0].srttunnellist_size()==0)
					{
						f1[0].valid=0;
					}
			}

			while(f1[1].srttunnellist_size()>0 && f1[1].func_bot_nec(cap_matr)== 0 && f1[1].valid == 1)
			{
					f1[1].tunnel_list.remove(0);
					if(f1[1].srttunnellist_size()==0)
					{
						f1[1].valid=0;
					}
			}
			//--------------------------------------------------
			
			
			if(f1[0].valid == 1 && f1[1].valid == 1)
			{

				double c = f1[0].func_bot_nec(cap_matr);
				c = Math.round(c * 100);
				c = c/100;
				double d = f1[1].func_bot_nec(cap_matr);
				d = Math.round(d * 100);
				d = d/100;
				double g = f1[0].d2 - f1[0].d1; //d2 = unsatisfied
				g = Math.round(g * 100);
				g = g/100;
				double h = f1[1].d2 - f1[1].d1;
				h = Math.round(h * 100);
				h = h/100;
				
				if(tunnel_comparison(f1[0].tunnel_list.get(0),f1[1].tunnel_list.get(0)) == true)
				{
					
					if(((y0 + y1)>= Math.max(c, d))||(y0 >= g)||(y1 >= h)||(y0 >= c)||(y1 >= d))
					{
						
						
						f_share = f_share - 0.001;
						
						y2 = f1[0].limit_getter(0, f_share) - f1[0].d1;
						y2 = Math.round(y2 * 100);
						y2 = y2/100;
						y3 = f1[1].limit_getter(1, f_share) - f1[1].d1;
						y3 = Math.round(y3 * 100);
						y3 = y3/100;
						cap_matr = f1[0].path_updation(y2, cap_matr);
						f1[0].d1 = f1[0].d1 + y2;
						
						cap_matr = f1[1].path_updation(y3, cap_matr);
						f1[1].d1 = f1[1].d1 + y3;
						
						f_share_l.add(f_share);
						
						System.out.println("\t" + f1[0].tunnel_list.get(0) +"\t"+ "Shared"+ "\t" + "Functional_Group0" + "\t" + y2 + "\t" + f_share );
						System.out.println("\t" + f1[1].tunnel_list.get(0) +"\t"+ "Shared"+ "\t" + "Functional_Group1" + "\t" + y3 + "\t" + f_share );
						
						if(y0+y1 > Math.max(c, d))
						{
							f1[0].tunnel_list.remove(0);
							f1[1].tunnel_list.remove(0);
						}
						else if (y0 >= c)
						{
							
							f1[0].tunnel_list.remove(0);
							if (f1[0].srttunnellist_size()== 0)
							{
								f1[0].valid = 0;
							}
						}
						else if (y1 >= d)
						{
							f1[1].tunnel_list.remove(0);
							if (f1[1].srttunnellist_size()== 0)
							{
								f1[1].valid = 0;
							}
						}

						if(y0 >= g)
						{
							f1[0].valid = 0;
						}
						if(y1 >= h)
						{
							f1[1].valid = 0;
						}

						f_share = f_share + 0.001;
					}
				}
				else
				{					
					if((y0 > c)||(y1 > d)||(y0 > g)||(y1>h))
					{
						f_share = f_share - 0.001;
						y2 = f1[0].limit_getter(0, f_share) - f1[0].d1;
						y2 = Math.round(y2 * 100);
						y2 = y2/100;
						y3 = f1[1].limit_getter(1, f_share) - f1[1].d1;
						y3 = Math.round(y3 * 100);
						y3 = y3/100;
						cap_matr = f1[0].path_updation(y2, cap_matr);
						f1[0].d1 = f1[0].d1 + y2;
						cap_matr = f1[1].path_updation(y3, cap_matr);
						f1[1].d1 = f1[1].d1 + y3;
						
						f_share_l.add(f_share);
						
						System.out.println("\t" + f1[0].tunnel_list.get(0) + "\t"+ "Pvt"+ "\t" + "FG0" + "\t" + y2 + "\t" + f_share );
						System.out.println("\t" + f1[1].tunnel_list.get(0) +"\t"+ "Pvt"+ "\t" + "FG1" + "\t" + y3 + "\t" + f_share );
						

						
						if(y0 > c)
						{
							f1[0].tunnel_list.remove(0);
						}
						else if(y1 > d)
						{
							f1[1].tunnel_list.remove(0);
						}
						else if(y0 >= g)
						{
							f1[0].valid = 0;
						}
						else if(y1 >= h)
						{
							f1[1].valid = 0;
						}
					
						f_share = f_share + 0.001;
						
					}
				}
			}
			
			else if(f1[0].valid == 1 || f1[1].valid == 1)
			{
				if(f1[0].valid == 1)
				{
					//System.out.println("Active FG - FG0");
					double c = f1[0].func_bot_nec(cap_matr);
					double g = f1[0].d2 - f1[0].d1;
					if((y0 > c)||(y0 > g))
					{
						f_share = f_share - 0.001;
						y2 = f1[0].limit_getter(0, f_share) - f1[0].d1;
						y2 = Math.round(y2 * 100);
						y2 = y2/100;

						cap_matr = f1[0].path_updation(y2, cap_matr);
						f1[0].d1 = f1[0].d1 + y2;
						f_share_l.add(f_share);
						
						System.out.println("\t" + f1[0].tunnel_list.get(0) +"\t"+ "Private"+"\t" + "FG0" + "\t" + y2 + "\t" + f_share );
						
						if(y0 >= c)
						{
							f1[0].tunnel_list.remove(0);
						}
						if(y0 >= g)
						{
							f1[0].valid = 0;
						}
						f_share = f_share + 0.001;
					}
				}
				else if(f1[1].valid == 1)
				{
					
					double d = f1[1].func_bot_nec(cap_matr);
					double h = f1[1].d2 - f1[1].d1;

					if((y1 >= d)||(y1 >= h))
					{
						f_share = f_share - 0.001;
						y3 = f1[1].limit_getter(1, f_share) - f1[1].d1;
						y3 = Math.round(y3 * 100);
						y3 = y3/100;
						cap_matr = f1[1].path_updation(y3, cap_matr);
						f_share_l.add(f_share);
						System.out.println("\t" + f1[1].tunnel_list.get(0) + "\t"+ "Private"+"\t" + "Functional_Group1" + "\t" + y3 + "\t" + f_share );
						
						if(y1 >= d)
						{
							f1[1].tunnel_list.remove(0);
							if(f1[1].srttunnellist_size() == 0)
							{
								f1[1].valid = 0;
							}
						}
						if(y1 >= h)
						{
							f1[1].valid = 0;
						}
						f_share = f_share + 0.001;
						f1[1].d1 = f1[1].d1 + y3;
					}
					
				}
				else
				{
					System.out.println("Invalid");
				}

				
			}
			
			else
			{
				contn = false;
			}

			
			
			f_share = f_share + 0.001;
			
		}
		
		
	System.out.println();		
	System.out.println("Final Capacity_Matrix - ");	
	System.out.println();
	for(int i = 1; i<size_mat; i++)
	{
		for(int j = 1; j<size_mat; j++)
		{
			//System.out.print("\t"+maincapacitymatrix[i][j]);
		}
	}
	
	System.out.println(f_share_l);    
    }        
    public static boolean tunnel_comparison(String arg0, String arg1)
    {
    	String s0 = arg0;
    	String s1 = arg1;
    	int count = 0;
    	String[] s0arr = s0.split("-");
    	String[] s1arr = s1.split("-");
    	if (s1arr.length > s0arr.length)
    	{
    		for(int i = 0; i<=s0arr.length-2; i++)
    		{
    			String seq = "(.*)"+s0arr[i]+"-"+s0arr[i+1]+"(.*)";
    			if (s1.matches(seq) == true)
    			{
    				count++;
    			}
    		}
    	}
    	else
    	{
    		for(int i = 0; i<=s1arr.length-2; i++)
    		{
    			String seq = "(.*)"+s1arr[i]+"-"+s1arr[i+1]+"(.*)";
    			if (s0.matches(seq) == true)
    			{
    				count++;
    			}
    		}				
    	}    	
    	if (count == 0)
    	{
    		return false;
    	}
    	else
    	{
    		return true;
    	}
    }

}