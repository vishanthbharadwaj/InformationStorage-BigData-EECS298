
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;


public class GraphMap 
{
	int size_matrix = 37;
    private Map<String, LinkedHashSet<String>> m = new HashMap<String, LinkedHashSet<String>>();
    double[][] matrix_cap = new double[size_matrix][size_matrix];
    int[][] matrix_latency = new int[size_matrix][size_matrix];
    GraphMap()
    {
    	System.out.println("Mapping of graph done");
    	for (int i = 0; i<size_matrix; i++)
    	{
    		for(int j = 0; j<size_matrix; j++)
    		{
    			matrix_cap[i][j] = 0.0;
    			matrix_latency[i][j] = 999;
    		}
    	}
    }
    public int[][] latency_matrix()
    {
    	return matrix_latency;
    }
    public double[][] capacity_matrix()
    {
    	return matrix_cap;
    }
    
    public LinkedList<String> adjacent_Nodes(String l) 
    {
        LinkedHashSet<String> adjacent = m.get(l);
        if(adjacent==null) 
        {
            return new LinkedList<String>();
        }
        return new LinkedList<String>(adjacent);
    }
    public void twowayvertex(String n1, String n2, String n3, String n4) 
    {
        edge_add(n1, n2, n3, n4);
        edge_add(n2, n1, n3, n4);
    }
    public boolean Connection(String n1, String n2) 
    {
        Set<String> adjacent = m.get(n1);
        if(adjacent==null) 
        {
            return false;
        }
        return adjacent.contains(n2);
    }
    public void edge_add(String n1, String n2, String n3, String n4) 
    {
        int a2 = Integer.parseInt(n3);
        int a3 = Integer.parseInt(n4);
        LinkedHashSet<String> ajcnt = m.get(n1);
        if(ajcnt==null) 
        {
        	ajcnt = new LinkedHashSet<String>();
            m.put(n1, ajcnt);
        }
        ajcnt.add(n2);
        int p0 = Integer.parseInt(n1);
        int p1 = Integer.parseInt(n2);
        matrix_cap[p0][p1] = a2;
        matrix_latency[p0][p1] = a3;
    }
}
