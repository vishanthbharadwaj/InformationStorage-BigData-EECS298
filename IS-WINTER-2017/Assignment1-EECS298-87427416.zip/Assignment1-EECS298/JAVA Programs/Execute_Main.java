import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Execute_Main {
public static void main(String[] args) {
	System.out.println("Enter choice: 1(Fat) or 2(Dcell) 3(TE Algorithm)");
	Scanner sc = new Scanner(System.in);
	int i=sc.nextInt();
	if(i==1)
	{
		GraphMap g = new GraphMap();
		g.twowayvertex("1","17", "5", "1");
      g.twowayvertex("2", "17", "5", "1");
      g.twowayvertex("3", "18", "5", "1");
      g.twowayvertex("4", "18", "5", "1");
      g.twowayvertex("5", "19", "5", "1");
      g.twowayvertex("6", "19", "5", "1");
      g.twowayvertex("7", "20", "5", "1");
      g.twowayvertex("8", "20", "5", "1");
      g.twowayvertex("9", "21", "5", "1");
      g.twowayvertex("10", "21", "5", "1");
      g.twowayvertex("11", "22", "5", "1");
      g.twowayvertex("12", "22", "5", "1");
      g.twowayvertex("13", "23", "5", "1");
      g.twowayvertex("14", "23", "5", "1");
      g.twowayvertex("15", "24", "5", "1");
      g.twowayvertex("16", "24", "5", "1");
      g.twowayvertex("17", "25", "5", "1");
      g.twowayvertex("17", "26", "5", "1");
      g.twowayvertex("18", "25", "5", "1");
      g.twowayvertex("18", "26", "5", "1");
      g.twowayvertex("19", "27", "5", "1");
      g.twowayvertex("19", "28", "5", "1");
      g.twowayvertex("20", "27", "5", "1");
      g.twowayvertex("20", "28", "5", "1");
      g.twowayvertex("21", "29", "5", "1");
      g.twowayvertex("21", "30", "5", "1");
      g.twowayvertex("22", "29", "5", "1");
      g.twowayvertex("22", "30", "5", "1");
      g.twowayvertex("23", "31", "5", "1");
      g.twowayvertex("23", "32", "5", "1");
      g.twowayvertex("24", "31", "5", "1");
      g.twowayvertex("24", "32", "5", "1");
      g.twowayvertex("25", "33", "5", "1");
      g.twowayvertex("25", "34", "5", "1");
      g.twowayvertex("26", "35", "5", "1");
      g.twowayvertex("26", "36", "5", "1");
      g.twowayvertex("27", "33", "5", "1");
      g.twowayvertex("27", "34", "5", "1");
      g.twowayvertex("28", "35", "5", "1");
      g.twowayvertex("28", "36", "5", "1");
      g.twowayvertex("29", "33", "5", "1");
      g.twowayvertex("29", "34", "5", "1");
      g.twowayvertex("30", "35", "5", "1");
      g.twowayvertex("30", "36", "5", "1");
      g.twowayvertex("31", "33", "5", "1");
      g.twowayvertex("31", "34", "5", "1");
      g.twowayvertex("32", "35", "5", "1");
      g.twowayvertex("32", "36", "5", "1");	
      PathMap p = new PathMap();
      p.BFS(g);
	}
	else if(i==2)
	{
		GraphMap g = new GraphMap();
		g.twowayvertex("1", "21", "5", "1");
    	g.twowayvertex("2", "21", "5", "1");
    	g.twowayvertex("3", "21", "5", "1");
    	g.twowayvertex("4", "21", "5", "1");
    	g.twowayvertex("5", "22", "5", "1");
    	g.twowayvertex("6", "22", "5", "1");
    	g.twowayvertex("7", "22", "5", "1");
    	g.twowayvertex("8", "22", "5", "1");
    	g.twowayvertex("9", "23", "5", "1");
    	g.twowayvertex("10", "23", "5", "1");
    	g.twowayvertex("11", "23", "5", "1");
    	g.twowayvertex("12", "23", "5", "1");
    	g.twowayvertex("13", "24", "5", "1");
    	g.twowayvertex("14", "24", "5", "1");
    	g.twowayvertex("15", "24", "5", "1");
    	g.twowayvertex("16", "24", "5", "1");
    	g.twowayvertex("17", "25", "5", "1");
    	g.twowayvertex("18", "25", "5", "1");
    	g.twowayvertex("19", "25", "5", "1");
    	g.twowayvertex("20", "25", "5", "1");
    	g.twowayvertex("1", "5", "5", "1");
    	g.twowayvertex("2", "9", "5", "1");
    	g.twowayvertex("3", "13", "5", "1");
    	g.twowayvertex("4", "17", "5", "1");
    	g.twowayvertex("6", "10", "5", "1");
    	g.twowayvertex("7", "14", "5", "1");
    	g.twowayvertex("8", "18", "5", "1");
    	g.twowayvertex("11", "15", "5", "1");
    	g.twowayvertex("12", "19", "5", "1");
    	g.twowayvertex("16", "20", "5", "1");
    	PathMap p = new PathMap();
    	p.BFS(g);
	}
	else if(i==3)
	{
		TEAlgo t = new TEAlgo();
		t.m();
	}
	
}
}
