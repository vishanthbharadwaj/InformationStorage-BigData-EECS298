import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;


public class flgrp_class {
	int matrix_size = 37;
	int[][] fglrp_laten_matrix = new int[matrix_size][matrix_size];
	double d1;
	double d2;
	int valid = 1;
	
	ArrayList<String> tunnel_list = new ArrayList<String>();
	
	public int funct_latency_g(String s)
	{
		int l = 0;
		String[] arr = s.split("-");
		for(int i = 0; i<=arr.length-2; i++)
		{
			int c = Integer.parseInt(arr[i+1]);
			int r = Integer.parseInt(arr[i]);
			l = l + fglrp_laten_matrix[r][c];
		}
		return l;
	}
	flgrp_class(GraphMap g)
	{
		d1 = 0;
		System.out.println("Bandwidth Demand Value: ");
		Scanner sc = new Scanner(System.in);
		d2 = sc.nextInt();
		ArrayList<String> t_list = new ArrayList<String>();
		PathMap p = new PathMap();
		p.BFS(g);
		t_list = p.gettunnellist();

		fglrp_laten_matrix = g.latency_matrix();

		Map<String, Integer> h = new HashMap<String, Integer>();
		for (int i = 0; i< t_list.size();i++)
		{
			h.put(t_list.get(i), funct_latency_g(t_list.get(i)));			
		}

        Map<String, Integer> sortedMapAsc = mapsort(h, true);

        for (String key : sortedMapAsc.keySet())
        {
        	tunnel_list.add(key);      	
        }
        
        System.out.println(tunnel_list);
	}
	
	private static Map<String, Integer> mapsort(Map<String, Integer> h, final boolean order)
    {

        List<Entry<String, Integer>> l = new LinkedList<Entry<String, Integer>>(h.entrySet());
        Collections.sort(l, new Comparator<Entry<String, Integer>>()
        {
            public int compare(Entry<String, Integer> k1,
                    Entry<String, Integer> k2)
            {
                if (order)
                {
                    return k1.getValue().compareTo(k2.getValue());
                }
                else
                {
                    return k2.getValue().compareTo(k1.getValue());

                }
            }
        });
        Map<String, Integer> h2 = new LinkedHashMap<String, Integer>();
        for (Entry<String, Integer> entry : l)
        {
            h2.put(entry.getKey(), entry.getValue());
        }

        return h2;
    }
	
		
	public double frshr(int f, double l)
	{
		double x = 0.0;
		double y = l;
		if (f == 0)
		{
			x = (y/11);
		}
		else if (f == 1)
		{
			x = (y/0.5);
		}
		else
		{
			System.out.println("Please give Fair Shair:	");
		}
		return x;
	}
	public double func_bot_nec(double[][] m)
	{
			double b = 999;
			double[][] capacity_matrix = new double[matrix_size][matrix_size];
			capacity_matrix = m;
			String temp = tunnel_list.get(0);
			String[] arr = temp.split("-");
			for(int i = 0; i<=arr.length-2; i++)
			{
				int r = Integer.parseInt(arr[i]);
				int c = Integer.parseInt(arr[i+1]);
				double e = capacity_matrix[r][c];
				//Finding the least capacity (bottleneck) edge
				if (e < b)
				{
					b = e;
				}
			}
			return b;
	}

	public double limit_getter(int f, double fshair)
	{
		double x = fshair;
		double y = 0.0;
		if (f == 0)
		{
//-----------------------------Sample Problem Fairshare Equations-----------------------------
			if (x<=1.5)
			{
				y = (11*x);				
			}
			else if(x>1.5 && x<5)
			{
				y = 15+x;
			}
			else
			{
				y = 20;
			}
//------------------------------------------------------------------------------------------
		}
		else if (f == 1)
		{
//------------------------------Sample Problem Fairshare Equations----------------------------
			if (x < 10)
			{
				y = (0.5*x);								
			}
			else
			{
				y = 5;
			}
//-------------------------------------------------------------------------------------------
		}
		else
		{
			System.out.println("Please give Fair Shair: ");
		}
		return y;
	}	
	
	
	public void sort_tunnellist_update()
	{
		tunnel_list.remove(0);
	}
	
	public int srttunnellist_size()
	{
		return tunnel_list.size();
	}
	public double[][] path_updation(double f,double[][] min_cap_mat)
	{
		double[][] fg_mat_cap = new double[matrix_size][matrix_size];
		fg_mat_cap = min_cap_mat;
		String s = tunnel_list.get(0);
		String[] arr = s.split("-");
		for(int i = 0; i<=arr.length-2; i++)
		{
			int row = Integer.parseInt(arr[i]);
			int column = Integer.parseInt(arr[i+1]);
			if(fg_mat_cap[row][column] - f <= 0.1)
			{
				fg_mat_cap[row][column] = 0;
			}
			else
			{
				fg_mat_cap[row][column] = fg_mat_cap[row][column] - f;				
			}
			fg_mat_cap[row][column] = Math.round(fg_mat_cap[row][column] * 100);
			fg_mat_cap[row][column] = fg_mat_cap[row][column]/100;
		}
		return fg_mat_cap;
	}
}
