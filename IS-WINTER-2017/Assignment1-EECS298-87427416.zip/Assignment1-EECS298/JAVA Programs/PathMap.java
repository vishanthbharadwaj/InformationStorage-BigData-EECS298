import java.util.*;
import java.util.LinkedList;
import java.util.Scanner;

public class PathMap
{
	public static int cnt=0;
	String begin;
	String finish;
	LinkedList<String> visit = new LinkedList<String>();
	ArrayList<String> t_list = new ArrayList<String>(); //tunnel_list
	
	PathMap()
	{
    System.out.println("Enter the Source Node - ");
    Scanner sc = new Scanner(System.in);
    begin = sc.nextLine();
    System.out.println("Enter the Sink Node - ");
    finish = sc.nextLine();
    //sc.close();
    visit.add(begin);
	}
	 public ArrayList<String> gettunnellist()
	    {
	    	return(t_list);
	    }
	  public void printPath(LinkedList<String> v) 
	    {
	    	String p = "";
	        for (String node : v) 
	        {
	            p = p +node + "-";
	        }
	        int l = p.length();
	        p = p.substring(0, l-1);
	        t_list.add(p);
	        System.out.println(p);
	        cnt++;
	        System.out.println("Path Number is"+cnt);
	    }
	  
	  
    public void BFS(GraphMap g) 
    {
        LinkedList<String> n = g.adjacent_Nodes(visit.getLast());
        for (String node : n) 
        {
            if (visit.contains(node)) 
            {
                continue;
            }
            if (node.equals(finish)) 
            {
                visit.add(node);
                printPath(visit);
                visit.removeLast();
                break;
            }
        }
        for (String node : n) 
        {
            if (visit.contains(node) || node.equals(finish)) 
            {
                continue;
            }
            visit.addLast(node);
            BFS(g);
            visit.removeLast();
        }
    }
}