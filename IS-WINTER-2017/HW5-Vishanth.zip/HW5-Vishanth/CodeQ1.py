import numpy as np
lmda = 1
ms = [1.1, 1.5, 2, 3, 9]TIME_DURATION = 200arr_t = []ag_m = 0arr_int = []time_arr = 0while time_arr < TIME_DURATION:    arrival_interval = np.random.exponential(1.0 / lmda)
    arr_int.append(arrival_interval)
    time_arr += arrival_interval
    arr_t.append(time_arr)
print "Arrival time:", arr_int
print "Avg arrival time:", np.mean(arr_t)
print "Avg difference between two arrivals:", np.mean(arr_int)
for meow in ms:
    ag_m += meow
agg_f = ag_m / len(ms)
agg_f = agg_f * 3.14
print agg_f
for meow in ms:
    serv_t = np.random.exponential(1.0 / meow, len(arr_t))
    print "Average service time for meu =", meow, ":", np.mean(serv_t)
    print serv_t
    resp = []
    completion = []
    for jbc in xrange(len(arr_t)):
        time_arr = arr_t[jbc]
        serv_t2 = serv_t[jbc]
        if jbc == 0:
            completion_time = time_arr + serv_t2
        elif completion[jbc-1] < time_arr:
            completion_time = time_arr + serv_t2
        else:
            completion_time = completion[jbc-1] + serv_t2
        last_completed = completion_time
        completion.append(completion_time)
        resp.append(completion_time-time_arr)
        print completion
        print resp
    print "Average response time for meu =", meow, ":", np.mean(resp)
    print "Server utilization for meu =", meow, ":", sum(serv_t) / last_completed