import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;


public class FileCopyWithProgress {
	public static void m() throws IOException {

		FileSystem hdfs =FileSystem.get(new Configuration());
		Path homeDir=hdfs.getHomeDirectory();
		//Print the home directory
		System.out.println("Home folder -" +homeDir);
		Path localFilePath = new Path("/Users/User/Desktop/Eclipse/eclipse/Eclipse.app/Contents/Ubuntu/DAA_Coding/p2/a");
		Path localFilePath2 = new Path("/Users/User/Desktop/Eclipse/eclipse/Eclipse.app/Contents/Ubuntu/DAA_Coding/p2/b");
		Path localFilePath3 = new Path("f5.txt");
		Path localFilePath4 = new Path("f6.txt");
		hdfs.copyFromLocalFile(localFilePath, homeDir); //a
		hdfs.copyFromLocalFile(localFilePath2, homeDir); //b
		hdfs.copyFromLocalFile(localFilePath3, homeDir);  //f5
		hdfs.copyFromLocalFile(localFilePath4, homeDir);       //f6 
		
		try {
			Path parPath1 = new Path(homeDir+”./f5.txt");
			Path parPath2 = new Path(homeDir+”./f6.txt");
			Path downloadTo = new Path(“~/testdir”);
			System.out.println("Target location- " + downloadTo);
			hdfs.copyToLocalFile(parPath1, downloadTo);  //f5
			hdfs.copyToLocalFile(parPath2, downloadTo);     //f6   
			System.out.println("Success");
		}
		catch(Exception e){
			e.getMessage();
		}
	}
}