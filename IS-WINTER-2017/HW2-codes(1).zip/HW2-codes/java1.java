import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
public class java1 {
public static void main(String[] args) throws IOException {
	//File f = new File("/home/vish/Downloads/a1.txt");
	File f = new File("/Users/User/Downloads/a1.txt");
	FileInputStream fis = new FileInputStream(f);
	 
	//Construct BufferedReader from InputStreamReader
	BufferedReader br = new BufferedReader(new InputStreamReader(fis));
	int a[] = new int[2];
	String line = null;
	int i=0;
	while ((line = br.readLine()) != null) {
		a[i]=Integer.parseInt(line);
		i++;
	}
	System.out.println(a[0]);
	System.out.println(a[1]);
	br.close();
	File f2 = new File("/Users/User/Downloads/b1.txt");
	FileInputStream fis2 = new FileInputStream(f2);
	 
	//Construct BufferedReader from InputStreamReader
	BufferedReader br2 = new BufferedReader(new InputStreamReader(fis2));
	int b[] = new int[2];
	String line2 = null;
	int i2=0;
	while ((line2 = br2.readLine()) != null) {
		b[i2]=Integer.parseInt(line2);
		i2++;
	}
	System.out.println(b[0]);
	System.out.println(b[1]);
	br.close();
	
int ai=a[0]; //p1
int aj=a[1]; //p1
int ak=b[0]; //p2
int al=b[1]; //p2
int aq=0;
int aw=0;
aq=ai^ak;  //p3.1
aw=aj^al;  //p3.2
int ax= ai^al ;//p4.1
int ay = aj^ak^al; //p4.2;
System.out.println("n3: "+aq+" n3: "+aw);
System.out.println("n4: "+ax+" n4: "+ay);


//////////////////////////////


Runtime.getRuntime().exec("rm -rf f1.txt");
Runtime.getRuntime().exec("rm -rf f2.txt");

Runtime.getRuntime().exec("rm -rf f5.txt");
Runtime.getRuntime().exec("rm -rf f6.txt");
try{
    PrintWriter writer5 = new PrintWriter("f5.txt", "UTF-8");
    writer5.println(aq);
    writer5.println(aw);
    writer5.close();
} catch (IOException e) {}

try{
    PrintWriter writer6 = new PrintWriter("f6.txt", "UTF-8");
    writer6.println(ax);
    writer6.println(ay);
    writer6.close();
} catch (IOException e2) {
   // do something
}

FileCopyWithProgress f1 = new FileCopyWithProgress();
f1.m(null);

int a1 = aq^aw^ay;
int b1=aq^aw^ax^ay^aw;
int c1 = aq^ay^aw^aq;
int d1 = aq^aw^ax^ay;
System.out.println("n1: "+a1+" n1: "+b1);
System.out.println("n2: "+c1+" n2: "+d1);

try{
    PrintWriter writer = new PrintWriter("f1.txt", "UTF-8");
    writer.println(a1);
    writer.println(b1);
    writer.close();
} catch (IOException e) {}

try{
    PrintWriter writer2 = new PrintWriter("f2.txt", "UTF-8");
    writer2.println(c1);
    writer2.println(d1);
    writer2.close();
} catch (IOException e2) {
   // do something
}
//	System.out.println("Files transfered from Base to hdfs");
//	System.out.println("Files transfered from hdfs to Base");
}
}
// f1 and f2 are final output files similar to a1 and b1
